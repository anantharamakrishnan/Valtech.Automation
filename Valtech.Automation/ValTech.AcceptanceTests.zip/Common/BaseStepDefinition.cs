﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using ValTechAUT.AcceptanceTests.Pages;
using TechTalk.SpecFlow;
using System.Threading;

namespace ValTechAUT.AcceptanceTests.Common
{
    [Binding]
    public class BaseStepDefinition : BasePage
    {

        #region SharedSteps
       
        #endregion
    }
}
