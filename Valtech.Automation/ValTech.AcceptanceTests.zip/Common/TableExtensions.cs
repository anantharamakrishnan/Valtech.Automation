﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace ValTechAUT.AcceptanceTests.Common
{
    public class TableExtensions
    {
        public static DataTable ToDataTable(Table table)
        {
            var dataTable = new DataTable();

            //Implement a foreach for a datatable

            return dataTable;
        }
    }
}
