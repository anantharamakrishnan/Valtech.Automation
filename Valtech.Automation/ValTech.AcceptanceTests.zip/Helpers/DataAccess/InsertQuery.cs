﻿using System;

namespace ArgusHandel.AcceptanceTests.Helpers.DataAccess
{
    public static class InsertQuery
    {
        public static string InsertIntraDayData_sql = $@"
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values ( (select max(id)+1 from HANDEL_INTRADAY),
15357, to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi'),
5.95 , to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,5.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values ( (select max(id)+1 from HANDEL_INTRADAY),
15359, to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi'),
5.00 , to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,2.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values ( (select max(id)+1 from HANDEL_INTRADAY),
15361, to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi'),
5.0 , to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,3.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values ( (select max(id)+1 from HANDEL_INTRADAY),
18613,to_date('{DateTime.Now.Date} 15:00', 'yyyy/mm/dd hh24:mi'),
8.99 , to_date('{DateTime.Now.Date} 15:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,4.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values ( (select max(id)+1 from HANDEL_INTRADAY),
18614, to_date('{DateTime.Now.Date} 15:00', 'yyyy/mm/dd hh24:mi'),
15.36 , to_date('{DateTime.Now.Date} 15:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,5.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values ( (select max(id)+1 from HANDEL_INTRADAY),
15365, to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi'),
12.55 , to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,6.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values ( (select max(id)+1 from HANDEL_INTRADAY),
15367,to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi'),
12.56 , to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,7.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values ( (select max(id)+1 from HANDEL_INTRADAY),
15369,to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi'),
13.56 ,to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,8.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values ((select max(id)+1 from HANDEL_INTRADAY),
15371,to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi'),
13.56 , to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,9.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
15371,to_date('{DateTime.Now.Date} 13:00', 'yyyy/mm/dd hh24:mi'),
13.58 ,to_date('{DateTime.Now.Date} 13:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,2.50 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
15371,to_date('{DateTime.Now.Date} 15:00', 'yyyy/mm/dd hh24:mi'),
13.59 ,to_date('{DateTime.Now.Date} 15:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,90.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
15373,to_date('{DateTime.Now.Date} 13:00', 'yyyy/mm/dd hh24:mi'),
6.55,to_date('{DateTime.Now.Date} 13:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,1.25 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
15375,to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi'),
1.26 ,to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,8.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
15377,to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi'),
1.27 ,to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,5.23 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
18601,to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi'),
81.27 ,to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,10.32 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
18602,to_date('{DateTime.Now.Date} 09:00', 'yyyy/mm/dd hh24:mi'),
81.77 ,to_date('{DateTime.Now.Date} 09:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,6.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
18602,to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi'),
81.78,to_date('{DateTime.Now.Date} 11:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,7.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
18602,to_date('{DateTime.Now.Date} 13:00', 'yyyy/mm/dd hh24:mi'),
51.78 ,to_date('{DateTime.Now.Date} 13:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,8.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
15381,to_date('{DateTime.Now.Date} 09:00', 'yyyy/mm/dd hh24:mi'),
51.78 ,to_date('{DateTime.Now.Date} 09:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,4.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
15383,to_date('{DateTime.Now.Date} 09:00', 'yyyy/mm/dd hh24:mi'),
51.78 ,to_date('{DateTime.Now.Date} 09:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,3.96 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
15385,to_date('{DateTime.Now.Date} 09:00', 'yyyy/mm/dd hh24:mi'),
51.78 ,to_date('{DateTime.Now.Date} 09:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
15387,to_date('{DateTime.Now.Date} 09:00', 'yyyy/mm/dd hh24:mi'),
51.78 ,to_date('{DateTime.Now.Date} 09:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,5.00 );
insert into HANDEL_INTRADAY
(id,code_id,PERIOD,EOD_VALUE,EOD_DATE,ICE_SETTLEMENT_PRE,ICE_SETTLEMENT_UNIT,ICE_SETTLEMENT_FX,ICE_SETTLEMENT,ICE_LATEST_PRE,ICE_LATEST_UNIT,ICE_LATEST_FX,ICE_LATEST,DIFF,VALUE)
values((select max(id)+1 from HANDEL_INTRADAY),
15387,to_date('{DateTime.Now.Date} 10:00', 'yyyy/mm/dd hh24:mi'),
52.78 ,to_date('{DateTime.Now.Date} 10:00', 'yyyy/mm/dd hh24:mi') ,
0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,0.00 ,4.00 );";

    }
}